function fetch(data){
   
  var req = new XMLHttpRequest();
      req.open("GET","http://localhost/Ajax/response.php?datavalue="+data,true);
      req.send();

      req.onreadystatechange = function(){
        if(req.readyState == 4 && req.status == 200 ){
          document.getElementById('district').innerHTML = req.responseText;
        }
      }
}

