<?php 

$name = $_GET['datavalue'];

$d1 = array('PUNE','MUMBAI','NAGPUR','YAVATMAL','BULDHANA');
$d2 = array('GANDHINAGAR','SURAT','UDHANA','VADODARA');
$d3 = array('KORBA','BHOPAL','INDORE','JABALPUR','BURHANPUR');
$d4 = array('LAKHNOW','KANPUR','BHGALPUR','AMETHI','GORAKHPUR');
$d5 = array('JAIPUR','JODHPUR','AJAMER','KOTA','DHOLPUR');

if($name == "Maharashtra"){
  foreach($d1 as $b){
    echo "<option> $b </option>";
  }
}

 elseif($name == "Gujrat"){
  foreach($d2 as $b){
    echo "<option> $b </option>";
  }
}

elseif($name == "Madhya Pradesh"){
  foreach($d3 as $b){
    echo "<option> $b </option>";
  }
}

elseif($name == "Uttar Pradesh"){
  foreach($d4 as $b){
    echo "<option> $b </option>";
  }
}

elseif($name == "Rajshtan"){
  foreach($d5 as $b){
    echo "<option> $b </option>";
  }
}



else{
  echo "<option> Choose your state first!!! </option>";
}
?>